
import { useState } from "react";
import { Dialog } from "@headlessui/react";

const photos = [
  "/photos/sample1.jpg",
  "/photos/sample2.jpg",
  "/photos/sample3.jpg",
  "/photos/sample4.jpg",
  "/photos/sample5.jpg",
];

export default function PhotoPortfolio() {
  const [selected, setSelected] = useState(null);

  return (
    <div className="min-h-screen bg-neutral-100 p-4">
      <h1 className="text-3xl font-bold text-center my-8">我的攝影作品集</h1>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 max-w-6xl mx-auto">
        {photos.map((src, idx) => (
          <img
            key={idx}
            src={src}
            alt={`作品 ${idx + 1}`}
            className="w-full h-48 object-cover rounded-xl cursor-pointer hover:opacity-80 transition"
            onClick={() => setSelected(src)}
          />
        ))}
      </div>

      <Dialog open={!!selected} onClose={() => setSelected(null)} className="fixed inset-0 z-50">
        <div className="fixed inset-0 bg-black/60" aria-hidden="true" />
        <div className="fixed inset-0 flex items-center justify-center p-4">
          <Dialog.Panel className="max-w-3xl w-full">
            <img src={selected || ""} alt="放大作品" className="rounded-xl shadow-lg" />
          </Dialog.Panel>
        </div>
      </Dialog>
    </div>
  );
}
